using System;
using System.Drawing;
using System.Threading.Tasks;
using System.Windows.Forms;
using AntdUI;
using RentalSystemUI.Controllers;
using Microsoft.VisualBasic; // Ensure Reference Added

namespace RentalSystemUI.Forms
{
    public partial class Form1 : Form
    {
        private DatabaseHelper db = new DatabaseHelper();
        private string selectedRole = "Tenant";
        private bool dragging = false;
        private Point dragCursorPoint, dragFormPoint;

        public Form1()
        {
            InitializeComponent();
            SetupVisuals();
            AttachDragEvents(this);
            if (panel1 != null) AttachDragEvents(panel1);
            if (panel2 != null) AttachDragEvents(panel2);
            if (pictureBox1 != null) AttachDragEvents(pictureBox1);
        }

        private void AttachDragEvents(Control control)
        {
            control.MouseDown += Form_MouseDown;
            control.MouseMove += Form_MouseMove;
            control.MouseUp += Form_MouseUp;
        }

        private void SetupVisuals()
        {
            if (pictureBox1 != null)
            {
                lblMain.Parent = pictureBox1; lblBlue.Parent = pictureBox1; lblSub.Parent = pictureBox1;
                lblMain.BackColor = Color.Transparent; lblBlue.BackColor = Color.Transparent; lblSub.BackColor = Color.Transparent;
            }
            pnlLogin.Visible = true;
            pnlSignup.Visible = false;
        }

        // ============================================
        //  LOGIN LOGIC
        // ============================================
        private void btnSignIn_Click(object sender, EventArgs e)
        {
            string email = txtLoginEmail.Text.Trim();
            string pass = txtLoginPass.Text.Trim();

            if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(pass))
            {
                AntdUI.Message.error(this, "Please fill in all fields.");
                return;
            }

            if (db.ValidateUser(email, pass, out string role, out string name))
            {
                AntdUI.Message.success(this, $"Welcome back, {name}!");
                this.Hide();
                new RentAllSearch().Show();
            }
            else
            {
                AntdUI.Message.error(this, "Invalid Email or Password.");
            }
        }

        // ============================================
        //  FORGOT PASSWORD
        // ============================================
        private async void lblForgot_Click(object sender, EventArgs e)
        {
            string email = Interaction.InputBox("Enter your registered email address:", "Reset Password", "");
            if (string.IsNullOrEmpty(email)) return;

            if (!db.UserExists(email, ""))
            {
                AntdUI.Message.error(this, "Email not found.");
                return;
            }

            string otp = new Random().Next(100000, 999999).ToString();

            // Send email asynchronously
            try
            {
                if (await EmailHelper.SendOtp(email, otp))
                {
                    string code = Interaction.InputBox("Enter the code we sent you:", "Verify Code");
                    if (code == otp)
                    {
                        string newPass = Interaction.InputBox("Enter your new password:", "New Password");
                        if (!string.IsNullOrEmpty(newPass))
                        {
                            db.UpdatePassword(email, newPass);
                            AntdUI.Message.success(this, "Password Updated! Please Login.");
                        }
                    }
                    else AntdUI.Message.error(this, "Incorrect OTP.");
                }
            }
            catch (Exception ex)
            {
                AntdUI.Message.error(this, "Failed to send email: " + ex.Message);
            }
        }

        // ============================================
        //  SIGNUP LOGIC (With Email OTP)
        // ============================================
        private async void BtnSignup_Click(object sender, EventArgs e)
        {
            string name = txtSignupName.Text.Trim();
            string email = txtSignupEmail.Text.Trim();
            string phone = txtSignupPhone.Text.Trim();
            string pass = txtSignupPass.Text.Trim();

            if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(email) || string.IsNullOrEmpty(pass) || string.IsNullOrEmpty(phone))
            {
                AntdUI.Message.error(this, "Fill all fields.");
                return;
            }
            if (!chkAgree.Checked)
            {
                AntdUI.Message.warn(this, "Agree to Terms.");
                return;
            }

            // Check DB
            if (db.UserExists(email, phone))
            {
                AntdUI.Message.error(this, "Account already exists.");
                return;
            }

            // Send OTP
            string otp = new Random().Next(100000, 999999).ToString();
            try
            {
                bool sent = await EmailHelper.SendOtp(email, otp);

                if (!sent)
                {
                    AntdUI.Message.error(this, "Could not send verification email.");
                    return;
                }

                string entered = Interaction.InputBox($"Enter code sent to {email}", "Verify Account");
                if (entered == otp)
                {
                    // Register
                    if (db.RegisterUser(name, email, phone, pass, selectedRole))
                    {
                        AntdUI.Message.success(this, "Account Created! Login now.");
                        SwitchToLogin(this, EventArgs.Empty);
                    }
                    else AntdUI.Message.error(this, "Database Error.");
                }
                else AntdUI.Message.error(this, "Invalid Code.");
            }
            catch (Exception ex)
            {
                AntdUI.Message.error(this, "Error sending OTP: " + ex.Message);
            }
        }

        // --- Role Toggle ---
        private void RoleButton_Click(object sender, EventArgs e)
        {
            var btn = sender as AntdUI.Button;
            if (btn == btnRoleTenant)
            {
                selectedRole = "Tenant";
                btnRoleTenant.Type = AntdUI.TTypeMini.Primary; btnRoleTenant.ForeColor = Color.White;
                btnRoleLandlord.Type = AntdUI.TTypeMini.Default; btnRoleLandlord.ForeColor = Color.Gray;
            }
            else
            {
                selectedRole = "Landlord";
                btnRoleLandlord.Type = AntdUI.TTypeMini.Primary; btnRoleLandlord.ForeColor = Color.White;
                btnRoleTenant.Type = AntdUI.TTypeMini.Default; btnRoleTenant.ForeColor = Color.Gray;
            }
        }

        // --- Navigation ---
        private void SwitchToSignup(object sender, EventArgs e) { pnlLogin.Visible = false; pnlSignup.Visible = true; }
        private void SwitchToLogin(object sender, EventArgs e) { pnlSignup.Visible = false; pnlLogin.Visible = true; }

        // --- Window & Dummy Events ---
        private void btnClose_Click(object sender, EventArgs e) { Application.Exit(); }
        private void btnMinimize_Click(object sender, EventArgs e) { this.WindowState = FormWindowState.Minimized; }
        private void btnGoogle_Click(object sender, EventArgs e) { AntdUI.Message.info(this, "Google Clicked"); }
        private void btnSignupFB_Click(object sender, EventArgs e) { AntdUI.Message.info(this, "Facebook Clicked"); }
        private void pictureBox1_Click(object sender, EventArgs e) { }
        private void label4_Click(object sender, EventArgs e) { }
        private void label1_Click(object sender, EventArgs e) { }
        private void Form_MouseDown(object? sender, MouseEventArgs e) { dragging = true; dragCursorPoint = Cursor.Position; dragFormPoint = this.Location; }
        private void Form_MouseMove(object? sender, MouseEventArgs e) { if (dragging) { Point dif = Point.Subtract(Cursor.Position, new Size(dragCursorPoint)); this.Location = Point.Add(dragFormPoint, new Size(dif)); } }
        private void Form_MouseUp(object? sender, MouseEventArgs e) { dragging = false; }
    }
}